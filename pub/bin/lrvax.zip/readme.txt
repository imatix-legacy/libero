    ------------------------------------------------------------------
                               Libero Readme File
    ------------------------------------------------------------------
    Copyright:  Copyright (c) 1991-96 iMatix
    Author:     Pieter A. Hintjens
    E-mail:     info@imatix.com
    Web:        http://www.imatix.com

    This readme file is deliberately left empty.  All information is
    available on our website.  You can get complete documentation in
    HTML format from the above address, or by sending us an e-mail.
    ------------------------------------------------------------------
