-------------------------------------------------------------------------------
Libero Example Packages
-------------------------------------------------------------------------------

Written:    22 Oct 1995
Revised:    10 May 1996

Author:     Pieter A. Hintjens <ph@imatix.com>

Notes:      These packages are meant to show how Libero is used in some real
            working programs.  I will add examples to this archive as I can.
            To install a package you need PKUnzip or InfoZip unzip.  The
            archives are created in MS-DOS format (text files with CRLF).
            To unzip on UNIX using InfoZip unzip use the -a option.

Contents:   Package:        Description:
            INSTALL.ZIP     Libero 'install' script for UNIX (ksh)
            CONFIG.ZIP      Configuration manager system (ksh)
            ACMS.ZIP        Multithreaded agent for VAX/VMS (C)
            TCPIP.ZIP       TCP/IP server (C)
            PICTURE.ZIP     COBOL picture parser (C, COBOL)
            EXPR.ZIP        Expression parsers (C, COBOL, MASM, VB)
            ERBOT.ZIP       E-mail Robot (AWK)
            HTMLPP.ZIP      HTML preprocessor (Perl)
            STRIPPER.ZIP    C/C++ comment stripper (C)

Copyright:  (c) 1991-96 Pieter A. Hintjens.

            This program is free software; you can redistribute it and/or
            modify it under the terms of the GNU General Public License as
            published by the Free Software Foundation; either version 2 of
            the License, or (at your option) any later version.

            This program is distributed in the hope that it will be useful,
            but WITHOUT ANY WARRANTY; without even the implied warranty of
            MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
            GNU General Public License for more details.

            You should have received a copy of the GNU General Public License
            along with this program; if not, write to the Free Software
            Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
