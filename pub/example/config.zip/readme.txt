-------------------------------------------------------------------------------
Package:    Configuration Management System
-------------------------------------------------------------------------------

Written:    22 Oct 1995
Revised:    07 Dec 1995
Version:    1.1

Author:     Pieter A. Hintjens
            Pijlstraat 9
            2060 Antwerpen, Belgium
            ph@mymail.com
            (+323) 231.5277

Contents:   File:           Purpose:
            README   TXT    This file
            CONTROL  L      Dialog for configuration-management script
            CONTROL  MOD    Source code (modules)
            CONTROL         Generated UNIX script
            LRSCHEMA KSH    Customised schema for Korn-shell scripts
            GATE     C      Sentinel program serialises access to files

Copyright:  (c) 1991-96 Pieter A. Hintjens.

            This program is free software; you can redistribute it and/or
            modify it under the terms of the GNU General Public License as
            published by the Free Software Foundation; either version 2 of
            the License, or (at your option) any later version.

            This program is distributed in the hope that it will be useful,
            but WITHOUT ANY WARRANTY; without even the implied warranty of
            MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
            GNU General Public License for more details.

            You should have received a copy of the GNU General Public License
            along with this program; if not, write to the Free Software
            Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
