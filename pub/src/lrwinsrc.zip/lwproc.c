/*===========================================================================*
 *                                                                           *
 *  lwproc.c    Libero/Windows procedure library for Visual Basic            *
 *              Linked as LWPROC.DLL.  See LWPROC.HDR for declarations.      *
 *                                                                           *
 *  Written:    94/04/21  Pieter Hintjens <ph@imatix.com>                    *
 *  Revised:    96/12/29                                                     *
 *                                                                           *
 *  FSM Code Generator.  Copyright (c) 1991-96 Pieter A. Hintjens.           *
 *===========================================================================*/

#include "prelude.h"                    /*  Public definitions               */
#include "lrpriv.h"                     /*  Private definitions              */
#include "lrsymb.h"                     /*  Symbol table functions           */
#include "vbapi.h"                      /*  VB API definitions               */

/*  These static areas are used in place of dynamic memory allocation for    */
/*  reasons of simplicity and efficiency.  I like it better.  So there.      */

#define MAX_HANDLES  64                 /*  Up to 64 open streams / process  */
#define STATE_READY  12345              /*  Identifies open files in table   */
#define COMMENT_CHAR '!'                /*  Start of comment on line         */

static struct
  {                                     /*  Fine-control of each input file  */
    int  state;                         /*  Must be STATE_READY to use file  */
    int  line_nbr;                      /*  Current input line number, 1..n  */
    int  line_pos;                      /*  Used for tab stops, 0..n-1       */
    Bool crlf;                          /*  True if MS-DOS CRLF found        */
  }
fdata [MAX_HANDLES];

static char
    buffer    [LINE_MAX + 1],           /*  String work space                */
    altbuffer [LINE_MAX + 1];           /*  String work space                */

static void  Buffer_put (char *Line);
static char *Buffer_get (void);

/*
 *  The buffer is held as a wrap-around queue of lines.  New data is added
 *  to the Head, which eventually bumps-up against the Tail; then the Tail
 *  also incremented.  Such a queue has these properties:
 *
 *      - When Tail = Head, the queue is empty.
 *      - The maximum number of entries is (size - 1)
 *      - Head and Tail may go from 0 to (size - 1)
 *      - To increment either pointer, do this:
 *          if (++pointer == size) pointer = 0;
 */

#define BUFFER_SIZE   256               /*  Save up to 255 lines             */
static char  W_line [LINE_MAX + 1];
static char *Buffer [BUFFER_SIZE];
static int   Head = 0;
static int   Tail = 0;


int CALLBACK
LibMain
  ( HANDLE hInstance,
    WORD wDataSeg,
    WORD wHeapSize,
    LPSTR lpszCmdLine )
/*  The following is required only under Windows version 3.1                 */
/*  Win32 does not require or support UnlockData()                           */
{
   if (wHeapSize > 0)
       UnlockData (0);                  /*  Unlock data segment of library   */
   return 1;
}


/*  -------------------------------------------------------------------------
 *  Lib_format
 *
 *  Formats a name in different ways depending on the format option:
 *
 *      0 = external      Some-Name-Like-This
 *      1 = internal      Some Name Like This
 *      2 = COBOL         SOME-NAME-LIKE-THIS
 *
 *  Punctuation marks are converted to spaces or hyphens.  Removes
 *  leading spaces.  Accepts a name in many different styles.
 *
 *  Returns VB string containing formatted-name.
 */

#define FORMAT_EXTERNAL     0
#define FORMAT_INTERNAL     1
#define FORMAT_COBOL        2

HLSTR __export CALLBACK
Lib_format
  ( HLSTR instring, int format )
{
    HLSTR VBstring;                     /*  Handle to cleaned-string         */
    char  ch;                           /*  Next char in name                */
    char  prevch;                       /*  Skip leading spaces              */
    Bool  capitalise;                   /*  If TRUE, capitalises next char   */
    word  scan;                         /*  Scan through name                */
    word  outsize;                      /*  Size of name on output           */
    word  insize;                       /*  Size of name on input            */

    insize     = VBGetHlstr (instring, buffer, LINE_MAX);
    outsize    = 0;
    prevch     = ' ';                   /*  Skip leading spaces              */
    capitalise = TRUE;                  /*  Capitalise first word            */

    for (scan = 0; scan < insize; scan++)
      {
        ch = buffer [scan];
        if (isalnum (ch) || ch == '$')
          {
            buffer [outsize++] = (char) (capitalise? toupper (ch):
                                                     tolower (ch));
            capitalise = (format == FORMAT_COBOL);
            prevch = ch;
          }
        else
          {
            capitalise = TRUE;
            if (format == FORMAT_INTERNAL)
              {
                if (prevch != ' ')
                    buffer [outsize++] = ' ';
                prevch = ' ';
              }
            else
                buffer [outsize++] = '-';
          }
      }
    /*  Convert into VB string and return to caller                          */
    VBstring = VBCreateTempHlstr (buffer, outsize);
    return (VBstring);
}


/*  -------------------------------------------------------------------------
 *  Lib_valid
 *
 *  Checks whether name is valid.  Permits only a letter followed by letters,
 *  digits, or embedded hyphens.  Ignores the case of letters.  Returns 1 if
 *  the name is valid, or 0 if not.  Also allows a "$" at start.
 */

int __export CALLBACK
Lib_valid
  ( HLSTR instring )
{
    int  feedback = 1;                  /*  Assume name is valid             */
    word insize;                        /*  Size of name on input            */
    word scan;                          /*  Scan through name                */

    insize = VBGetHlstr (instring, buffer, LINE_MAX);
    for (scan = 0; scan < insize; scan++)
      {
        if (isalnum (buffer [scan]))    /*  Allow alpha and numeric chars    */
            continue;
        else
        if (buffer [scan] == '-')
            if (scan + 1 < insize       /*  Allow '-' only if not at start   */
            &&  scan > 0)               /*    or at end of name              */
                continue;
            else
                feedback = 0;
        else
        if (buffer [scan] == '$'        /*  Allow '$' only at start          */
        &&  scan == 0)
            continue;
        else
            feedback = 0;
      }
    return (feedback);
}


/*  -------------------------------------------------------------------------
 *  Lib_file_type
 *
 *  Looks at the specified file and returns an indicator of the type of the
 *  file, if possible.  The returned codes are:
 *
 *     -1 = file not found
 *      0 = Libero dialog file (default)
 *      1 = ETK dialog, getdia format
 *      2 = ETK dialog file, MS-DOS [F80] format
 *      3 = ETK dialog, UNIX fixed-length format
 */

#define TYPE_LIBERO         0
#define TYPE_ETK_MSDOS      1
#define TYPE_ETK_UNIX       2
#define TYPE_GETDIA         3

int __export CALLBACK
Lib_file_type
  ( HLSTR filename )
{
    int handle;                         /*  Opened file handle               */
    int count;                          /*  Bytes read from file             */

    VBGetHlstr (filename, buffer, LINE_MAX);
    handle = open (buffer, O_RDONLY + O_BINARY, S_IREAD | S_IWRITE);
    if (handle < 0)
        return (handle);                /*  File not found                   */

    count = read (handle, buffer, LINE_MAX);
    close (handle);

    /*  ETK dialogs on MS-DOS start with "f<Ctrl-Z><80>"                     */
    if (buffer [0] == 'f' && buffer [1] == 26 && buffer [2] == 80)
        return (TYPE_ETK_MSDOS);

    /*  ETK dialogs on UNIX start with "DIALOG DATA V"                       */
    if (memcmp (buffer, "DIALOG DATA V", 13) == 0)
        /*  Check that line is not variable-length: look for X spaces        */
        if (memcmp (buffer + 16, "                    ", 20) == 0)
            return (TYPE_ETK_UNIX);

    /*  Getdia dialogs start with "PARAMS ("                                 */
    if (memcmp (buffer, "PARAMS (", 8) == 0)
        return (TYPE_GETDIA);

    /*  Anything else can be assumed to be a Libero dialog file              */
    return (TYPE_LIBERO);
}


/*  -------------------------------------------------------------------------
 *  Lib_file_open
 *
 *  Opens the specified file, and returns a file handle, or -1 if there was
 *  an error.  The file mode can be one of: "r" = read, "w" = write, "a" =
 *  append.  The file is always opened in binary mode.
 */

int __export CALLBACK
Lib_file_open
  ( HLSTR filename,
    HLSTR mode )
{
    int handle;
    int flags;

    VBGetHlstr (mode, buffer, LINE_MAX);
    if (*buffer == 'r')
        flags = O_RDONLY;
    else
    if (*buffer == 'w')
        flags = O_WRONLY | O_CREAT | O_TRUNC;
    else
    if (*buffer == 'a')
        flags = O_APPEND;

    VBGetHlstr (filename, buffer, LINE_MAX);
    handle = open (buffer, flags + O_BINARY, S_IREAD | S_IWRITE);
    if (handle >= 0)
      {
        fdata [handle].line_nbr  = 1;
        fdata [handle].line_pos  = 0;
        fdata [handle].crlf      = FALSE;
        fdata [handle].state     = STATE_READY;
      }
    return (handle);
}


/*  -------------------------------------------------------------------------
 *  Lib_file_close
 *
 *  Closes the specified file.  Returns 0 if there was no error, or -1 if
 *  there was an error.
 */

int __export CALLBACK
Lib_file_close
  ( int handle )
{
    if (fdata [handle].state != STATE_READY)
        return (-1);                    /*  File is not open                 */

    fdata [handle].state = 0;
    return (close (handle));
}


/*  -------------------------------------------------------------------------
 *  Lib_file_token
 *
 *  Gets the next token from the file specified.  Tokens are text delimited
 *  by white space (spaces, tabs, end-of-line).  Returns the token, or "" if
 *  the file was exhausted.  Quotes or apostrophes delimit strings which are
 *  returned integraly, or until the end of the line.  '!' delimits a comment
 *  that continues until the end of the line.  This line holds two tokens:
 *
 *      -name="my name"    ! This is a comment
 *
 */

HLSTR __export CALLBACK
Lib_file_token
  ( int handle )
{
    HLSTR VBstring;                     /*  Handle to returned token         */
    char  nextch [1];
    int   count;
    int   toksize;
    int   tab_mark;                     /*  Position of next tab stop        */
    Bool  in_comment;                   /*  In comment text?                 */
    Bool  in_string;                    /*  Inside quotes?                   */
    char  delimiter;                    /*  String delimiter                 */

    /*  Build empty VB string to return in case of errors or EOF             */
    VBstring = VBCreateTempHlstr (NULL, 0);
    if (fdata [handle].state != STATE_READY)
        return (VBstring);              /*  File is not open                 */

    do                                  /*  Skip leading white space         */
      {
        count = read (handle, nextch, 1);
        if (count < 1)
            return (VBstring);          /*  End of file or error             */
        else
        if (*nextch == '\r')            /*  Found carriage-return            */
            fdata [handle].crlf = TRUE;
        else
        if (*nextch == '\n')
          {
            fdata [handle].line_nbr++;  /*  Count line                       */
            fdata [handle].line_pos = 0;
          }
        else
        if (*nextch == '\t')            /*  Calculate up to tab position     */
            fdata [handle].line_pos = ((fdata [handle].line_pos >> 3) << 3) + 8;
        else
        if (*nextch > ' ')
            fdata [handle].line_pos++;
      }
    until (*nextch > ' ');              /*  Have printable character         */

    in_string = FALSE;
    in_comment = FALSE;
    toksize = 0;                        /*  Initialise token to empty        */
    do                                  /*    and fill-up from file          */
      {
        /*  Handle start/end of string or start of comment                   */
        if (in_string)
            in_string = !(*nextch == delimiter);
        else
        if (in_comment)
          {
            /*  Do nothing special inside a comment                          */
          }
        else
        if (*nextch == '"' || *nextch == '\'')
          {
            in_string = TRUE;
            delimiter = *nextch;
          }
        else
        if (*nextch == COMMENT_CHAR)
            in_comment = TRUE;

        /*  Store next character in token buffer and read next character     */
        buffer [toksize++] = *nextch;
        count = read (handle, nextch, 1);

        if (count < 0)
            return (VBstring);          /*  Error occurred                   */
        else
        if (count == 0)                 /*  End of file                      */
            break;
        else
        if (*nextch == '\t' && (in_string || in_comment))
          {
            tab_mark = ((fdata [handle].line_pos >> 3) << 3) + 8;
            while (fdata [handle].line_pos < tab_mark)
              {
                buffer [toksize++] = ' ';
                fdata [handle].line_pos++;
              }
            *nextch = ' ';              /*  Treat tab as space               */
          }
        else
        if (*nextch == '\r')            /*  Found carriage-return            */
            fdata [handle].crlf = TRUE;
        else
        if (*nextch == '\n')
          {
            fdata [handle].line_nbr++;  /*  Count line                       */
            fdata [handle].line_pos = 0;
          }
        else
        if (*nextch > ' ')
            fdata [handle].line_pos++;
        else
        if (*nextch == ' ' && !in_string && !in_comment)
            break;                      /*  End of token if white-space      */
      }
    until (*nextch < ' ');              /*  Control characters end token     */

    /*  Convert into VB string and return to caller                          */
    VBGetHlstr (VBstring, NULL, 0);     /*  Delete temporary string          */
    VBstring = VBCreateTempHlstr (buffer, toksize);
    return (VBstring);
}


/*  -------------------------------------------------------------------------
 *  Lib_file_read_line
 *
 *  Gets the next line from the file specified.  Lines are delimited by a
 *  newline or end-of-file.  Expands tabs.
 */

HLSTR __export CALLBACK
Lib_file_read_line
  ( int handle )
{
    HLSTR VBstring;                     /*  Handle to returned token         */
    char  nextch [1];
    int   count;
    int   toksize;
    int   tab_mark;                     /*  Position of next tab stop        */

    /*  Build empty VB string to return in case of errors or EOF             */
    VBstring = VBCreateTempHlstr (NULL, 0);
    if (fdata [handle].state != STATE_READY)
        return (VBstring);              /*  File is not open                 */

    toksize = 0;                        /*  Initialise token to empty        */
    do                                  /*    and fill-up from file          */
      {
        count = read (handle, nextch, 1);
        if (count < 0)
            return (VBstring);          /*  Error occurred                   */
        else
        if (count == 0)                 /*  End of file                      */
            break;
        else
        if (*nextch == '\t')
          {
            tab_mark = ((fdata [handle].line_pos >> 3) << 3) + 8;
            while (fdata [handle].line_pos < tab_mark)
              {
                buffer [toksize++] = ' ';
                fdata [handle].line_pos++;
              }
          }
        else
        if (*nextch == '\r')            /*  Found carriage-return            */
            fdata [handle].crlf = TRUE;
        else
        if (*nextch == '\n')
          {
            fdata [handle].line_nbr++;  /*  Count line                       */
            fdata [handle].line_pos = 0;
          }
        else
        if (*nextch >= ' ')
          {
            fdata [handle].line_pos++;
            buffer [toksize++] = *nextch;
          }
      }
    until (*nextch == '\n');

    /*  Convert into VB string and return to caller                          */
    VBGetHlstr (VBstring, NULL, 0);     /*  Delete temporary string          */
    VBstring = VBCreateTempHlstr (buffer, toksize);
    return (VBstring);
}


/*  -------------------------------------------------------------------------
 *  Lib_file_write
 *
 *  Writes a string to a file, and appends either LF or CRLF depending on the
 *  value of crlf for the file.  Returns 0 if okay, -1 if errors occurred.
 */

int __export CALLBACK
Lib_file_write
  ( int handle,
    HLSTR string )
{
    int outsize;                        /*  Number of bytes to write         */

    if (fdata [handle].state != STATE_READY)
        return (-1);                    /*  File is not open                 */

    outsize = VBGetHlstr (string, buffer, LINE_MAX);
    if (fdata [handle].crlf)
      {
        strcat (buffer, "\r");
        outsize++;
      }
    strcat (buffer, "\n");
    outsize++;

    if (write (handle, buffer, outsize) < outsize)
        return (-1);
    else
        return (0);
}


/*  -------------------------------------------------------------------------
 *  Lib_file_line
 *
 *  Returns the current line number for the specified file.  The first line
 *  of text is line 1.
 */

int __export CALLBACK
Lib_file_line
  ( int handle )
{
    if (fdata [handle].state != STATE_READY)
        return (-1);                    /*  File is not open                 */

    return (fdata [handle].line_nbr);
}


/*  -------------------------------------------------------------------------
 *  Lib_file_crlf
 *
 *  Returns TRUE if the file contained CRLF sequences; FALSE if lines ended
 *  only in LF.  Call after reading the file, before closing it.
 */

int __export CALLBACK
Lib_file_crlf
  ( int handle )
{
    if (fdata [handle].state != STATE_READY)
        return (-1);                    /*  File is not open                 */

    return (fdata [handle].crlf);
}


/*  -------------------------------------------------------------------------
 *  Lib_file_crlf_set
 *
 *  Sets the crlf flag for the specified file.  This affects future Lib_file_
 *  write calls.  Returns 0 if no errors, -1 if an invalid handle was used.
 */

int __export CALLBACK
Lib_file_crlf_set
  ( int handle,
    int crlf )
{
    if (fdata [handle].state != STATE_READY)
        return (-1);                    /*  File is not open                 */
    else
      {
        fdata [handle].crlf = crlf;
        return (0);
      }
}


/*  -------------------------------------------------------------------------
 *  Lib_parse_option
 *
 *  Parses an option string according to Libero standards, and returns the
 *  separate components of the string.  Returns >= 0 if okay, < 0 if error.
 *
 *  Option string must be in format: [-]name=value where name is one of
 *  the switches defined by Libero.  Abbreviations of 3 or more characters
 *  are accepted.
 *
 *  Returns:     0  Option parsed without problems
 *               1  -NO used at start of option
 *              -1  Invalid switch character; must be '-'
 *              -2  Option name after switch is too short (< 3 chars)
 *              -3  Invalid option name; must be one defined in LRPRIV.H
 *                  In this case, the name is returned.
 *              -4  Bad value; not one of those accepted for switch
 *                  In this case, the name and value are returned.
 */

int __export CALLBACK
Lib_parse_option
  ( HLSTR VBoptstring,                  /*  String to parse                  */
    HLSTR VBoptname,                    /*  Returned option name, 3 chars    */
    HLSTR VBoptvalue )                  /*  Returned option value            */
{
    int
        feedback,                       /*  0 = normal, 1 = -NOxxx used      */
        optnbr,                         /*  Index into option_list           */
        length,                         /*  Length of option name            */
        in_string = 0;                  /*  1 when within quoted string      */
    char
       *name,                           /*  Pointer to option name           */
       *value,                          /*  Pointer to option value if any   */
       *check,                          /*  Points into value checklist      */
       *scan;                           /*  Scan and parse value string      */
    option
       *optptr;                         /*  Pointer to option in list        */

    /*  Get null-terminated option string from VB argument                   */
    VBGetHlstr (VBoptstring, buffer, LINE_MAX);
    VBSetHlstr (&VBoptname, NULL, 0);   /*  And clear return arguments       */
    VBSetHlstr (&VBoptvalue, NULL, 0);  /*    in case of errors in parsing   */

    if (*buffer != '-')
        return (-1);                    /*  Not - at start                   */

    StrLwr (strtok (buffer, "=:"));     /*  Cut name at '=' or ':'           */
    value = strtok (NULL, "");          /*  Get pointer to value, if any     */
    name  = buffer + 1;                 /*  Name starts past option ind.     */

    if (name [0] == 'n' && name [1] == 'o')
      {
        name += 2;
        feedback = 1;                   /*  -NOxxx used                      */
      }
    else
        feedback = 0;                   /*  Normal option                    */

    length = strlen (name);
    if (length < 3)
        return (-2);                    /*  Option name too short            */

    /*  Return first 3 chars of option name                                  */
    VBSetHlstr (&VBoptname, name, 3);

    for (optnbr = 0; optnbr < OPT_MAX; optnbr++)
      {
        optptr = &option_list [optnbr];
        if (strncmp (optptr-> name, name, length) == 0)
            break;
      }
    if (optnbr == OPT_MAX)
        return (-3);                    /*  Option name is not known         */

    if ((optptr-> type == '='           /*  New value for option             */
    ||   optptr-> type == '+')          /*  Added value for option           */
    &&  *value)                         /*  Pick-up value string if any      */
      {
        /*  Convert to lowercase except within quotes                        */
        for (scan = value; *scan; scan++)
          {
            if (*scan == '\'' || *scan == '"')
                in_string = 1 - in_string;
            else
            if (!in_string)
                *scan = (char) tolower (*scan);
          }
        /*  If value starts and ends with a quote or apost, remove them      */
        if ((*value == '\'' || *value == '"')
        &&  (strlast (value) == *value))
          {
            StrClose (value, 0);        /*  Remove first and last quote      */
            strlast (value) = 0;
          }
        /*  Return value string to caller                                    */
        VBSetHlstr (&VBoptvalue, value, strlen (value));

        /*  If switch accepts fixed set of values, check we fit one          */
        for (check = optptr-> check; check; )
          {
            if (streq (value, check))
                break;
            check = strchr (check, 0) + 1;
            if (*check == 0)
                return (-4);            /*  Not one of valid fixed values    */
          }
      }
    return (feedback);
}


/*  -------------------------------------------------------------------------
 *  Lib_force_extension
 *
 *  Returns a filename based on that supplied, but with the extension set to
 *  a fixed specified value.
 */

HLSTR __export CALLBACK
Lib_force_extension
  ( HLSTR VBfilename,                   /*  Filename, perhaps with path      */
    HLSTR VBextension )                 /*  Required extension (max 4 chars) */
{
    HLSTR VBstring;                     /*  Handle to returned token         */

    /*  Get null-terminated strings from VB arguments                        */
    VBGetHlstr (VBfilename, buffer, LINE_MAX);
    VBGetHlstr (VBextension, altbuffer, 4);

    FixedExtension (buffer, buffer, altbuffer);
    /*  Convert into VB string and return to caller                          */
    VBstring = VBCreateTempHlstr (buffer, strlen (buffer));
    return (VBstring);
}


/*  -------------------------------------------------------------------------
 *  Lib_find_file
 *
 *  Searches a path for the specified file; returns the full filename if
 *  found, else returns an empty string.
 */

HLSTR __export CALLBACK
Lib_find_file
  ( HLSTR VBpathname,                   /*  Name of path symbol, eg. PATH    */
    HLSTR VBfilename )                  /*  File name and extension          */
{
    HLSTR VBstring;                     /*  Handle to returned token         */
    char  pathname [30 + 1];            /*  Maximum size of path name        */
    char *found_name;                   /*  Return from FileWhere()          */

    /*  Get null-terminated strings from VB arguments                        */
    VBGetHlstr (VBpathname, pathname, 30);
    VBGetHlstr (VBfilename, buffer, LINE_MAX);
    found_name = FileWhere ('r', pathname, buffer, NULL);

    /*  Convert into VB string and return to caller                          */
    if (found_name)
        VBstring = VBCreateTempHlstr (found_name, strlen (found_name));
    else
        VBstring = VBCreateTempHlstr (NULL, 0);

    return (VBstring);
}


/*  -------------------------------------------------------------------------
 *  Lib_match_strings
 *
 *  Compares two strings, returns an index indicating how well they match.
 */

int __export CALLBACK
Lib_match_strings
  ( HLSTR VBstring1,                    /*  String to match against          */
    HLSTR VBstring2 )                   /*  String to match                  */
{
    /*  Get null-terminated strings from VB arguments                        */
    VBGetHlstr (VBstring1, buffer, LINE_MAX);
    VBGetHlstr (VBstring2, altbuffer, LINE_MAX);
    /*  Match strings and return comparison index                            */
    return (StrMatch (buffer, altbuffer));
}


/*  -------------------------------------------------------------------------
 *  Lib_generate
 *
 *  Generates code for dialog as specified.  Options come first from Ini file,
 *  then from dialog file, and lastly from command_line.  Console output is
 *  saved in log file.
 *
 *  Returns 0 if okay, 1 if there was an error.
 */

int __export CALLBACK
Lib_generate
  ( HLSTR VBfilename,                   /*  Dialog filename, optional ext.   */
    HLSTR VBpre_options,                /*  -options before loading file     */
    HLSTR VBpost_options )              /*  -options after loading file      */
{
    char
        *MessageFile;                   /*  Message file name                */
    lrstat
        stats;                          /*  Dialog statistics                */
    lrnode
        listhead;                       /*  Dialog list header node          */
    static char
        trace_file [LR_FILENAMEMAX+1],  /*  Trace file with extension        */
        fullname   [LR_FILENAMEMAX+1];  /*  Dialog file with extension       */

    Head = 0;                           /*  Clear output buffer              */
    Tail = 0;

    printf ("LIBERO v%s (c) 1991-97 iMatix\n",
             LIBERO_VERSION);

    lr_reset_options ();                /*  Set default options              */
    lr_parse_option_line ("-author='Your Name'");
    lr_parse_option_line ("-check");
    lr_parse_option_line ("-generate");
    lr_parse_option_line ("-stubs");
    lr_parse_option_line ("-sort");
    lr_parse_option_line ("-schema=lrschema.c");
    lr_parse_option_line ("-path='PATH'");
    lr_parse_option_line ("-defaults=defaults");
    lr_parse_option_line ("-style=plain");

    /*  Parse options that we want to have before we start working           */
    /*  Then parse -ini file, if any was specified (by default is empty)     */
    VBGetHlstr (VBpre_options, buffer, LINE_MAX);
    lr_parse_option_line (buffer);
    if (OPT_INITIAL.value && strused (OPT_INITIAL.value))
        lr_parse_option_file (OPT_INITIAL.value);

    /*  If -settings specified, print-out current settings                   */
    lr_show_options ("command");

    MessageFile = FileWhere ('r', OPT_PATH.value, MESSAGE_FILE, NULL);
    if (MessageFile == NULL)
      {
        printf ("Cannot find message file %s on %s path\n", MESSAGE_FILE,
                 OPT_PATH.value);
        return (RET_ERROR);
      }
    OpenMessageFile (MessageFile);

    VBGetHlstr (VBfilename, buffer, LR_FILENAMEMAX);
    if (DefaultExtension (fullname, buffer, "l") == -1)
      {
        PrintMessage (MSG_INVALID_FILENAME, buffer);
        return (RET_ERROR);
      }
    if (!FileExists (fullname))
      {
        PrintMessage (MSG_DIALOG_FILE_NF, fullname);
        return (RET_ERROR);
      }
    PrintMessage (MSG_PROCESSING, fullname);
    VBGetHlstr (VBpost_options, buffer, LINE_MAX);
    lr_parse_option_file (fullname);    /*  Get options from .l file         */
    lr_parse_option_line (buffer);      /*    and then post_options line     */
    lr_show_options      (fullname);    /*  Show settings if -sett used      */

    if (OPT_TRACE.flags & OPT_ON)       /*  Create trace file if wanted      */
      {
        FixedExtension (trace_file, fullname, "lst");
        SetTraceFile   (trace_file, 'w');
        if (!TraceFile)                 /*  If error on file, halt           */
          {
            PrintMessage (MSG_TRACE_FILE_ERROR, trace_file);
            return (RET_ERROR);
          }
        EnableTrace ();                 /*  Else enable tracing to file      */
      }
    Trace ("Pass 1: loading dialog");
    if (lr_load_dialog (&listhead, &stats, fullname) == -1)
        return (RET_ERROR);

    Trace ("Pass 2: sorting dialog");
    if (lr_sort_dialog (&listhead, &stats) == -1)
        return (RET_ERROR);

    if (stats.states && stats.events && stats.modules)
      {
        /*  Generate code from -schema if specified                          */
        if (OPT_SCHEMA.value)
          {
            Trace ("Pass 3: generating code");
            if (lr_generate_code (&listhead, &stats, fullname) == -1)
                return (RET_ERROR);
          }
      }
    else
        PrintMessage (MSG_DIALOG_EMPTY, fullname);

    Trace ("Pass 4: cleaning-up");
    lr_free_memory (&listhead, &stats); /*  Free table memory                */
    if (TraceFile)
      {
        fclose (TraceFile);
        TraceFile = NULL;
      }
    CloseMessageFile ();
    return (RET_OKAY);
}


/*  -------------------------------------------------------------------------
 *  Lib_read_pipe
 *
 *  Returns next line of piped output, if any.  Returns empty string if there
 *  was no output waiting; returns output string if there was something.
 */

HLSTR __export CALLBACK
Lib_read_pipe
  ( void )
{
    HLSTR VBstring;                     /*  Handle to returned string        */
    char *piped_line;                   /*  Line of text from pipe           */

    piped_line = Buffer_get ();
    if (piped_line)
        VBstring = VBCreateTempHlstr (piped_line, strlen (piped_line));
    else
        VBstring = VBCreateTempHlstr (NULL, 0);

    return (VBstring);
}


/*  -------------------------------------------------------------------------
 *  Console output pipe functions
 *
 *  Functions puts, printf, fprintf are redirected here: output is prepared
 *  and sent to wrap-around pipe buffer, to be read using Lib_read_pipe.
 */

#undef puts                             /*  Reset to normal definitions      */
#undef printf
#undef fprintf

int W_puts (const char *string)
{
    sprintf (W_line, "%s", string);
    Buffer_put (W_line);
    return (strlen (W_line));
}

int W_printf (const char *format, ...)
{
    va_list argptr;                     /*  Argument list pointer            */

    va_start (argptr, format);          /*  Start variable args processing   */
    vsprintf (W_line, format, argptr);
    va_end (argptr);                    /*  End variable args processing     */
    Buffer_put (W_line);
    return (strlen (W_line));
}

int W_fprintf (FILE *stream, const char *format, ...)
{
    va_list argptr;                     /*  Argument list pointer            */

    va_start (argptr, format);          /*  Start variable args processing   */
    vsprintf (W_line, format, argptr);
    va_end (argptr);                    /*  End variable args processing     */

    if (stream == stdout || stream == stderr)
        Buffer_put (W_line);
    else
        fprintf (stream, W_line);

    return (strlen (W_line));
}

void W_exit (int ExitCode)
{
    /*  Can't exit from a DLL                                                */
    sprintf (W_line, "Exit code = %d\n", ExitCode);
    Buffer_put (W_line);
}


/*  -------------------------------------------------------------------------
 *  Buffer_put
 *
 *  Adds the line to the buffer.  If the buffer was full, the oldest line
 *  is lost.
 */

void
Buffer_put (char *Line)
{
    if (++Head == BUFFER_SIZE)
        Head = 0;

    if (Head == Tail)
      {
        if (++Tail == BUFFER_SIZE)
            Tail = 0;
        free (Buffer [Tail]);
      }
    /*  Remove trailing newline if any                                       */
    if (strlast (Line) == '\n')
        strlast (Line) = 0;

    Buffer [Head] = StrDup (Line);
}


/*  -------------------------------------------------------------------------
 *  Buffer_get
 *
 *  Returns next line from buffer; if the buffer was empty returns NULL.
 */

char *
Buffer_get (void)
{
    static char
        this_line [LINE_MAX + 1];

    if (Head == Tail)
        return (NULL);
    else
      {
        if (++Tail == BUFFER_SIZE)
            Tail = 0;
        strcpy (this_line, Buffer [Tail]);
        free (Buffer [Tail]);
        return (this_line);
      }
}
